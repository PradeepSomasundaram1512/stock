"""Notification system module."""
