"""Market scanner module."""
